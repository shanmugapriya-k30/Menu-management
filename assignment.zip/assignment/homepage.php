<?php include "partials/header.php";
include "config/db.php";
?>
    

    <h1>Welcome to the Homepage</h1>

    <form method="post">
        <button type="submit" class="btn" name="goToTracker">Application Upgrade Tracker</button>
    </form>
    <br>
    <form method="post">
        <button type="submit" class="btn" name="goToTracker2">Effort Tracker</button>
    </form>

    <?php
    if (isset($_POST['goToTracker'])) {
        header("Location: upgradetracker.php");
        exit();
    }

        if (isset($_POST['goToTracker2'])) {
            header("Location: efforttable.php");
            exit();
        }

    ?>
    

<?php include "partials/footer.php";?>