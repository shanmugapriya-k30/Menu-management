package com.cts.OnlineDeliverySystem.controller;



import com.cts.OnlineDeliverySystem.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payments")
public class PaymentController {


    @Autowired
    private PaymentService paymentService;


    @GetMapping("/sample")
    public String sample(){
        return  "sample";
    }

    @GetMapping("/pay/{orderId}")
    public String handlePayment(@PathVariable int orderId) throws Exception {

        return paymentService.handlePayment(orderId);

    }

    @GetMapping("/success")
    public String paymentSuccess(@RequestParam("payment_intent_id") String stripePaymentIntendId){
        return paymentService.handleSuccesspayment(stripePaymentIntendId);
    }

    @GetMapping("/cancel")
    public String paymentFailure(@RequestParam("payment_intent_id") String stripePaymentIntendId){
        return paymentService.handlePaymentFailiure(stripePaymentIntendId);
    }
}