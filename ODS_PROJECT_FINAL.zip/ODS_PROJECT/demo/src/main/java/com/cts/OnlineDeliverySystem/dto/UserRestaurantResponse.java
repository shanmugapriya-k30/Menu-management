package com.cts.OnlineDeliverySystem.dto;
import com.cts.OnlineDeliverySystem.entity.Restaurant;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserRestaurantResponse {

    private List<RestaurantDTO> restaurant;
    private String message;


}
