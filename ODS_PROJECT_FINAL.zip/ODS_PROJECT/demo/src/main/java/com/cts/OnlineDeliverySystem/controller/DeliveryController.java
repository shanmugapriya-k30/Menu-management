package com.cts.OnlineDeliverySystem.controller;

import com.cts.OnlineDeliverySystem.entity.Delivery;
import com.cts.OnlineDeliverySystem.repository.DeliveryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DeliveryController {

    @Autowired
    private DeliveryRepository deliveryRepository;

    // Endpoint to track delivery status by orderId
    @GetMapping("/track-delivery")
    public String trackDelivery(@RequestParam Long orderId) {
        Delivery delivery = deliveryRepository.findByOrderOrderId(orderId)
                .orElseThrow(() -> new RuntimeException("Delivery not found for Order ID: " + orderId));
        return "Current Status: " + delivery.getStatus();
    }
}