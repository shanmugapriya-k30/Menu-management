package com.cts.OnlineDeliverySystem.service;

import com.cts.OnlineDeliverySystem.entity.Order;
import com.cts.OnlineDeliverySystem.entity.Payment;
import com.cts.OnlineDeliverySystem.repository.OrderRepository;
import com.cts.OnlineDeliverySystem.repository.PaymentRepository;
import com.stripe.Stripe;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Date;

@Service
public class PaymentService {


    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private DeliveryService deliveryService;

    @Value("${stripe.api.key}")
    private String stripeApiKey;



    public String handlePayment(long orderId) throws Exception{

        Order order = orderRepository.findById(orderId).orElseThrow();
        double amount=order.getTotalAmount();
        long amountInPaise =Math.round(amount*100);
        Stripe.apiKey = stripeApiKey;


        try {
            SessionCreateParams params = SessionCreateParams.builder()
                    .setMode(SessionCreateParams.Mode.PAYMENT)
                    .setSuccessUrl("http://localhost:8085/payments/success?payment_intent_id={CHECKOUT_SESSION_ID}")
                    .setCancelUrl("http://localhost:8085/payments/cancel?payment_intent_id={CHECKOUT_SESSION_ID}")
                    .addLineItem(SessionCreateParams.LineItem.builder()
                            .setQuantity(1L)
                            .setPriceData(

                                    SessionCreateParams.LineItem.PriceData.builder()
                                            .setCurrency("INR")
                                            .setUnitAmount(amountInPaise)
                                            .setProductData(

                                                    SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                            .setName("Order payment")
                                                            .build())
                                            .build())
                            .build())
                    .build();
            Session session = Session.create(params);

            //        save the payment Entity
            Payment payment = new Payment();

            payment.setTotalAmount(amount);
            payment.setPaymentMethod("card");
            payment.setPaymentStatus("pending");
            payment.setStripePaymentIntendId(session.getId());
            payment.setOrder(order);

            order.setPayment(payment);
            paymentRepository.save(payment);
            orderRepository.save(order);
            return session.getUrl();

        } catch (Exception e) {
            return "Error occurred while creating payment session: " + e.getMessage();
        }
    }

    //changing the payment status after payment
    public String handleSuccesspayment(String stripePaymentIntendId) {
        Payment payment =paymentRepository.findByStripePaymentIntendId(stripePaymentIntendId);
        payment.setPaymentStatus("success");
        payment.getOrder().setOrderStatus("Accepted");
        payment.getOrder().setOrderAcceptedTime(LocalDateTime.now());
        paymentRepository.save(payment);

//        call the assignAgentOrder to start the delivery
        deliveryService.assignAgentToOrder(payment.getOrder());
        return payment.getPaymentStatus();
    }

    public String handlePaymentFailiure(String stripePaymentIntendId) {
        Payment payment =paymentRepository.findByStripePaymentIntendId(stripePaymentIntendId);
        payment.setPaymentStatus("failure");
        payment.getOrder().setOrderStatus("PaymentPending");
        paymentRepository.save(payment);
        return payment.getPaymentStatus();
    }
}
