package com.cts.OnlineDeliverySystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineDeliverySystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineDeliverySystemApplication.class, args);
	}

}
